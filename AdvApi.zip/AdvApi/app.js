const express=require("express");
const jwt = require("jsonwebtoken");
const authorize = require("./Authmiddleware");
app=express()
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
const db = require("./db")
var dateTime = require('node-datetime');

app.post("/",function(req,res){

    // res.send("hello")s
    var fname=req.body.fname;

    var lname=req.body.lname;
    var mobileno=req.body.mobileno;
    var address=req.body.address;
    var country=req.body.country;
    var pincode=req.body.pincode;
    var Idproof=req.body.Idproof;
    var username=req.body.username;
    var email=req.body.email;
    var password=req.body.password;
    var dt = dateTime.create();
    var UpdatedAt = dt.format('Y-m-d H:M:S');

    var sql="INSERT INTO `register`(`FirstName`, `LastName`, `MobileNo`, `Address`, `Country`, `PinCode`, `IdProof`, `UserName`, `Email`, `Password`,`date`) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
    db.query(sql,[fname,lname,mobileno,address,country,pincode,Idproof,username,email,password,UpdatedAt],function(err,result){
        if (err) throw err
        else{
            res.send("Data has been submitted!")
        }
    })
})

app.post("/login",function(req,res){
    var email=req.body.email;
    var password=req.body.password;
    var sql=`select * from register where Email=? and Password=?`;
    db.query(sql,[email,password],function(err,result){
        if(result.length>0){
            // res.send("found")
            var token= jwt.sign({email:email},'secret',{expiresIn:"1h"})
            console.log(token)
        }
        res.send("Now you are logged in!")
    })
})

app.post("/contact",authorize(),function(req,res){
    var name=req.body.name;
    var email=req.body.email;
    var mobileno=req.body.mobileno;
    var address=req.body.address;   
    var message=req.body.message;
    var dt = dateTime.create();
    var UpdatedAt = dt.format('Y-m-d H:M:S');
   

    var sql="INSERT INTO `contact`(`Name`, `Email`, `MobileNo`, `Address`, `Message`,`date`) VALUES (?,?,?,?,?,?)";
    db.query(sql,[name,mobileno,address,email,message,UpdatedAt],function(err,result){
        if (err) throw err
        else{
            res.send("Your query has been submitted. we'll contact you as soon as possible.")
        }
    })
})


app.post("/upload",authorize(),function(req,res){
    var fname=req.body.fname;
    var lname=req.body.fname;
    var mobileno=req.body.mobileno;
    var address=req.body.address;
    var document=req.body.document;
    var dt = dateTime.create();
    var UpdatedAt = dt.format('Y-m-d H:M:S');

   

    var sql="INSERT INTO `upload`(`FirstName`, `LastName`, `MobileNo`, `Address`, `Document`, `UpdatedAt`) VALUES (?,?,?,?,?,?)";
    db.query(sql,[fname,lname,mobileno,address,document,UpdatedAt],function(err,result){
        if (err) throw err
        else{
            res.send("Successfully Uploaded!")
        }
    })
})

app.post("/onetoone",authorize(),function(req,res){
    var fname=req.body.fname;
    var lname=req.body.fname;
    var mobileno=req.body.mobileno;
    var address=req.body.address;
    var upload=req.body.upload;
    // var dt = dateTime.create();
    // var UpdatedAt = dt.format('Y-m-d H:M:S');

   

    var sql="INSERT INTO `onetoone`(`FirstName`, `LastName`, `Mobile`, `Address`, `Upload`) VALUES (?,?,?,?,?)";

    db.query(sql,[fname,lname,mobileno,address,upload],function(err,result){
        if (err) throw err
        else{
            res.send("Successfull!")
        }
    })
})


app.post("/course",authorize(),function(req,res){
    var name=req.body.name;
    var subject=req.body.subject;
    var thumbnail=req.body.thumbnail;
    var time=req.body.time;
    // var dt = dateTime.create();
    // var UpdatedAt = dt.format('Y-m-d H:M:S');

   

    var sql="INSERT INTO `courses`(`name`, `subject`, `thumbnail`, `time(inDays)`) VALUES (?,?,?,?";

    db.query(sql,[name,subject,thumbnail,time],function(err,result){
        if (err) throw err
        else{
            res.send("Successfull!")
        }
    })
})


app.get("/students",authorize(),function(req,res){
    var id=req.body.id;
    var sql=`select * from student where id=?`;
    db.query(sql,id,function(err,result){
        if (err) throw err
        else{
            res.send(result)
        }
    })
})



app.listen(5000)